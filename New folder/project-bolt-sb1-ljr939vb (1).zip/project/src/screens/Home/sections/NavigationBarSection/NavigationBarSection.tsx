import { ChevronRightIcon } from "lucide-react";
import React, { useState } from "react";
import { Button } from "../../../../components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "../../../../components/ui/navigation-menu";

export const NavigationBarSection = (): JSX.Element => {
  const [isOpen, setIsOpen] = useState(false);

  // Navigation links data
  const navLinks = [
    { title: "Home Page", href: "#" },
    { title: "About Us", href: "#" },
    { title: "Contact Us", href: "#" },
  ];

  // Explore pages data
  const explorePages = [
    {
      title: "Pricing Plans",
      description: "Discover our subscription options and benefits",
      icon: "/icon---relume.svg",
    },
    {
      title: "Creator Tools",
      description: "Empowering creators to monetize their content",
      icon: "/icon---relume.svg",
    },
    {
      title: "User Support",
      description: "Get help with your account and questions",
      icon: "/icon---relume.svg",
    },
    {
      title: "Blog Insights",
      description: "Read our latest articles and tips",
      icon: "/icon---relume.svg",
    },
  ];

  // Latest articles data
  const latestArticles = [
    {
      title: "Content Strategies",
      description: "Learn how to grow your audience effectively",
      icon: "/icon---relume.svg",
    },
    {
      title: "Success Stories",
      description: "Inspiring tales from our successful creators",
      icon: "/icon---relume.svg",
    },
    {
      title: "Community Events",
      description: "Join us for workshops and networking",
      icon: "/icon---relume.svg",
    },
    {
      title: "Featured Posts",
      description: "Highlighting top content from our creators",
      icon: "/icon---relume.svg",
    },
  ];

  // Blog posts data
  const blogPosts = [
    {
      title: "Boost Your Income",
      description: "Explore ways to maximize your earnings",
      image: "/placeholder-image-1.png",
    },
    {
      title: "Engagement Tips",
      description: "Strategies to enhance your audience interaction",
      image: "/placeholder-image-1.png",
    },
  ];

  return (
    <header className="flex flex-col w-full items-center relative bg-[#140f05] border-b-2 border-white">
      <div className="flex h-[72px] items-center justify-between px-16 py-0 relative w-full">
        <div className="flex items-center gap-6">
          <div className="relative w-[84px] h-9">
            <img
              className="absolute w-[70px] h-9 top-0 left-[7px]"
              alt="Logo"
              src="/logo-wide-1.svg"
            />
          </div>

          <NavigationMenu>
            <NavigationMenuList className="flex items-center gap-8">
              {navLinks.map((link, index) => (
                <NavigationMenuItem key={index}>
                  <NavigationMenuLink
                    href={link.href}
                    className="font-text-regular-normal text-white"
                  >
                    {link.title}
                  </NavigationMenuLink>
                </NavigationMenuItem>
              ))}

              <NavigationMenuItem>
                <NavigationMenuTrigger
                  onClick={() => setIsOpen(!isOpen)}
                  className="font-text-regular-normal text-white bg-transparent hover:bg-transparent focus:bg-transparent"
                >
                  More Links
                </NavigationMenuTrigger>
                <NavigationMenuContent className="w-[1440px] bg-[#140f05]">
                  <div className="flex w-full items-start">
                    <div className="gap-8 pl-16 pr-8 py-8 flex-1 grow flex items-start">
                      <div className="flex flex-1 grow flex-col items-start gap-4">
                        <h3 className="self-stretch font-text-small-semi-bold text-white">
                          Explore Our Pages
                        </h3>

                        <div className="flex flex-col items-start gap-4">
                          {explorePages.map((page, index) => (
                            <div
                              key={index}
                              className="w-[376px] h-[61px] gap-3 px-0 py-2 flex items-start"
                            >
                              <img
                                className="w-6 h-6"
                                alt="Icon"
                                src={page.icon}
                              />

                              <div className="flex flex-col items-start flex-1 grow">
                                <h4 className="self-stretch mt-[-1.00px] font-text-regular-semi-bold text-white">
                                  {page.title}
                                </h4>
                                <p className="self-stretch font-text-small-normal text-white">
                                  {page.description}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="flex flex-1 grow flex-col items-start gap-4">
                        <h3 className="self-stretch font-text-small-semi-bold text-white">
                          Latest Articles
                        </h3>

                        <div className="flex flex-col items-start gap-4">
                          {latestArticles.map((article, index) => (
                            <div
                              key={index}
                              className="w-[376px] h-[61px] gap-3 px-0 py-2 flex items-start"
                            >
                              <img
                                className="w-6 h-6"
                                alt="Icon"
                                src={article.icon}
                              />

                              <div className="flex flex-col items-start flex-1 grow">
                                <h4 className="self-stretch mt-[-1.00px] font-text-regular-semi-bold text-white">
                                  {article.title}
                                </h4>
                                <p className="self-stretch font-text-small-normal text-white">
                                  {article.description}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col w-[560px] items-start gap-4 pl-8 pr-24 py-8 self-stretch bg-[#140f05]">
                      <h3 className="self-stretch font-text-small-semi-bold text-white">
                        From Our Blog
                      </h3>

                      <div className="flex flex-col items-start gap-2 self-stretch w-full">
                        {blogPosts.map((post, index) => (
                          <div
                            key={index}
                            className="flex items-start gap-6 px-0 py-2 self-stretch w-full"
                          >
                            <img
                              className="w-40 h-[105px] object-cover"
                              alt="Blog thumbnail"
                              src={post.image}
                            />

                            <div className="flex flex-col items-start gap-2 flex-1 grow">
                              <div className="flex flex-col items-start gap-1 self-stretch w-full">
                                <h4 className="self-stretch mt-[-1.00px] font-text-regular-semi-bold text-white">
                                  {post.title}
                                </h4>
                                <p className="self-stretch font-text-small-normal text-white">
                                  {post.description}
                                </p>
                              </div>

                              <a
                                href="#"
                                className="font-text-small-link text-white underline"
                              >
                                Read more
                              </a>
                            </div>
                          </div>
                        ))}
                      </div>

                      <Button
                        variant="ghost"
                        className="text-white p-1 flex items-center gap-2"
                      >
                        <span className="font-text-regular-medium">Button</span>
                        <ChevronRightIcon className="w-6 h-6" />
                      </Button>
                    </div>
                  </div>
                </NavigationMenuContent>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>
        </div>

        <div className="flex items-center justify-center gap-4">
          <Button className="px-5 py-2 bg-[#f2f2f2] text-black rounded-[100px] border-2 border-solid border-black shadow-[0px_2px_2px_#00000026,inset_0px_-5px_0px_#00000026,inset_0px_4px_0px_#ffffff33]">
            <span className="font-text-regular-medium">Join</span>
          </Button>

          <Button className="px-5 py-2 bg-[#d6d3ce] text-black rounded-[100px] border-2 border-solid border-black shadow-[0px_2px_2px_#00000026,inset_0px_-5px_0px_#00000026,inset_0px_4px_0px_#ffffff33]">
            <span className="font-text-regular-medium">Start</span>
          </Button>
        </div>
      </div>
    </header>
  );
};
