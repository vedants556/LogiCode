import React from "react";
import { CallToActionSection } from "./sections/CallToActionSection";
import { ContentDisplaySection } from "./sections/ContentDisplaySection/ContentDisplaySection";
import { FooterSection } from "./sections/FooterSection";
import { HeaderSection } from "./sections/HeaderSection/HeaderSection";
import { LayoutContainerSection } from "./sections/LayoutContainerSection/LayoutContainerSection";
import { MainContentSection } from "./sections/MainContentSection";
import { MainLayoutSection } from "./sections/MainLayoutSection";
import { NavigationBarSection } from "./sections/NavigationBarSection/NavigationBarSection";
import { TestimonialsSection } from "./sections/TestimonialsSection/TestimonialsSection";

export const Home = (): JSX.Element => {
  return (
    <main className="flex flex-col w-full">
      <NavigationBarSection />
      <HeaderSection />
      <MainLayoutSection />
      <MainContentSection />
      <LayoutContainerSection />
      <ContentDisplaySection />
      <CallToActionSection />
      <TestimonialsSection />
      <FooterSection />
    </main>
  );
};
