import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const LayoutContainerSection = (): JSX.Element => {
  return (
    <section className="w-full bg-[#140f05] py-28 px-6 md:px-16">
      <div className="flex flex-col md:flex-row items-start gap-10 md:gap-20 max-w-[1440px] mx-auto">
        <div className="flex flex-col items-start gap-6 flex-1">
          <img
            className="w-12 h-12"
            alt="Icon relume"
            src="/icon---relume.svg"
          />

          <div className="flex flex-col items-start gap-6 w-full">
            <h2 className="text-[length:var(--heading-desktop-h3-font-size)] tracking-[var(--heading-desktop-h3-letter-spacing)] leading-[var(--heading-desktop-h3-line-height)] mt-[-1.00px] font-heading-desktop-h3 font-[number:var(--heading-desktop-h3-font-weight)] text-white [font-style:var(--heading-desktop-h3-font-style)]">
              Unlock Exclusive Content: Engage with Your Favorite Creators Like
              Never Before
            </h2>

            <p className="font-[number:var(--text-medium-normal-font-weight)] text-[length:var(--text-medium-normal-font-size)] leading-[var(--text-medium-normal-line-height)] font-text-medium-normal text-white tracking-[var(--text-medium-normal-letter-spacing)] [font-style:var(--text-medium-normal-font-style)]">
              Exclusive posts offer a unique glimpse into the lives and creative
              processes of your favorite creators. Subscribe now to access
              content that&apos;s only available to dedicated fans and support
              their journey.
            </p>
          </div>
        </div>

        <div className="flex-1 w-full md:w-auto">
          <Card className="border-0 bg-transparent">
            <CardContent className="p-0">
              <img
                className="w-full h-auto md:h-[640px] object-cover"
                alt="Placeholder image"
                src="/placeholder-image-5.png"
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};
