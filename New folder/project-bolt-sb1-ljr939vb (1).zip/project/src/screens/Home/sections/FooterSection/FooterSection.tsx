import {
  FacebookIcon,
  InstagramIcon,
  LinkedinIcon,
  TwitterIcon,
  YoutubeIcon,
} from "lucide-react";
import React from "react";
import { Separator } from "../../../../components/ui/separator";

export const FooterSection = (): JSX.Element => {
  // Navigation links data
  const navLinks = [
    "About Us",
    "Contact Us",
    "Support Center",
    "Blog Posts",
    "Join Now",
  ];

  // Social media icons data
  const socialIcons = [
    { icon: <FacebookIcon className="h-6 w-6" />, alt: "Facebook" },
    { icon: <InstagramIcon className="h-6 w-6" />, alt: "Instagram" },
    { icon: <TwitterIcon className="h-6 w-6" />, alt: "X" },
    { icon: <LinkedinIcon className="h-6 w-6" />, alt: "LinkedIn" },
    { icon: <YoutubeIcon className="h-6 w-6" />, alt: "YouTube" },
  ];

  // Footer links data
  const footerLinks = [
    { text: "© 2025 Relume. All rights reserved.", isLink: false },
    { text: "Privacy Policy", isLink: true },
    { text: "Terms of Service", isLink: true },
    { text: "Cookies Settings", isLink: true },
  ];

  return (
    <footer className="flex flex-col items-center gap-20 px-16 py-20 bg-[#140f05] w-full">
      <div className="flex items-center gap-8 w-full">
        {/* Logo */}
        <div className="flex flex-col items-start gap-6 flex-1">
          <div className="relative w-[84px] h-9">
            <img
              className="absolute w-[70px] h-9 top-0 left-[7px]"
              alt="Logo wide"
              src="/logo-wide-1.svg"
            />
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="flex items-start gap-8">
          {navLinks.map((link, index) => (
            <a
              key={index}
              href="#"
              className="font-text-small-semi-bold text-white whitespace-nowrap mt-[-1.00px]"
            >
              {link}
            </a>
          ))}
        </nav>

        {/* Social Media Icons */}
        <div className="flex items-center justify-end gap-3 flex-1">
          {socialIcons.map((social, index) => (
            <a key={index} href="#" aria-label={social.alt}>
              {social.icon}
            </a>
          ))}
        </div>
      </div>

      <div className="flex flex-col items-center gap-8 w-full">
        {/* Divider */}
        <Separator className="bg-white/20 h-0.5 w-full" />

        {/* Footer Links */}
        <div className="flex items-start gap-6">
          {footerLinks.map((link, index) => (
            <div
              key={index}
              className={`
                mt-[-1.00px] text-white whitespace-nowrap
                ${
                  link.isLink
                    ? "font-text-small-link underline"
                    : "font-text-small-normal"
                }
              `}
            >
              {link.isLink ? (
                <a href="#">{link.text}</a>
              ) : (
                <span>{link.text}</span>
              )}
            </div>
          ))}
        </div>
      </div>
    </footer>
  );
};
