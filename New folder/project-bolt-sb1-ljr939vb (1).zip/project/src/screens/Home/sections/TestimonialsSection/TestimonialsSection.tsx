import React from "react";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "../../../../components/ui/avatar";
import { Card, CardContent } from "../../../../components/ui/card";
import { Separator } from "../../../../components/ui/separator";

export const TestimonialsSection = (): JSX.Element => {
  const testimonialData = {
    rating: "/stars.svg",
    quote:
      '"This platform has transformed my ability to connect with fans and monetize my content effectively! I couldn\'t be happier with the support and tools provided."',
    author: {
      avatar: "/avatar-image.png",
      name: "Alex Johnson",
      role: "Content Creator, YouTube",
    },
    logo: "/placeholder-logo.svg",
  };

  return (
    <section className="bg-[#140f05] py-28 px-16 flex flex-col items-center gap-20 w-full">
      <Card className="bg-transparent border-none w-full max-w-[768px]">
        <CardContent className="flex flex-col items-center gap-8 p-0">
          <img className="flex-none" alt="Stars" src={testimonialData.rating} />

          <p className="text-center text-white font-heading-desktop-h5 text-[length:var(--heading-desktop-h5-font-size)] tracking-[var(--heading-desktop-h5-letter-spacing)] leading-[var(--heading-desktop-h5-line-height)] font-[number:var(--heading-desktop-h5-font-weight)] [font-style:var(--heading-desktop-h5-font-style)]">
            {testimonialData.quote}
          </p>

          <div className="flex items-center gap-5">
            <Avatar className="w-14 h-14">
              <AvatarImage src={testimonialData.author.avatar} alt="Author" />
              <AvatarFallback>AJ</AvatarFallback>
            </Avatar>

            <div className="flex flex-col items-start">
              <span className="font-text-regular-semi-bold text-white text-[length:var(--text-regular-semi-bold-font-size)] leading-[var(--text-regular-semi-bold-line-height)] tracking-[var(--text-regular-semi-bold-letter-spacing)] font-[number:var(--text-regular-semi-bold-font-weight)] [font-style:var(--text-regular-semi-bold-font-style)]">
                {testimonialData.author.name}
              </span>

              <span className="font-text-regular-normal text-white text-[length:var(--text-regular-normal-font-size)] leading-[var(--text-regular-normal-line-height)] tracking-[var(--text-regular-normal-letter-spacing)] font-[number:var(--text-regular-normal-font-weight)] [font-style:var(--text-regular-normal-font-style)]">
                {testimonialData.author.role}
              </span>
            </div>

            <Separator
              orientation="vertical"
              className="h-[61px] w-0.5 bg-white/20"
            />

            <img
              className="w-[120px] h-12"
              alt="Placeholder logo"
              src={testimonialData.logo}
            />
          </div>
        </CardContent>
      </Card>
    </section>
  );
};
