import React from "react";
import { Button } from "../../../../components/ui/button";

export const HeaderSection = (): JSX.Element => {
  return (
    <section className="flex flex-col w-full items-start gap-20 px-16 py-28 bg-[#140f05]">
      <div className="flex flex-col max-w-[768px] items-start gap-8">
        <div className="flex flex-col items-start gap-6 w-full">
          <h1 className="font-heading-desktop-h1 font-[number:var(--heading-desktop-h1-font-weight)] text-white text-[length:var(--heading-desktop-h1-font-size)] tracking-[var(--heading-desktop-h1-letter-spacing)] leading-[var(--heading-desktop-h1-line-height)] [font-style:var(--heading-desktop-h1-font-style)]">
            Unlock Your Creative Potential with Our Subscription Platform for
            Content Creators
          </h1>

          <p className="text-[length:var(--text-medium-normal-font-size)] leading-[var(--text-medium-normal-line-height)] font-text-medium-normal font-[number:var(--text-medium-normal-font-weight)] text-white tracking-[var(--text-medium-normal-letter-spacing)] [font-style:var(--text-medium-normal-font-style)]">
            Monetize your content effortlessly while connecting with your fans
            in a secure environment.
          </p>
        </div>

        <div className="flex items-start gap-4">
          <Button className="px-6 py-2.5 bg-[#d6d3ce] rounded-[100px] border-2 border-solid border-black shadow-[0px_2px_2px_#00000026,inset_0px_-5px_0px_#00000026,inset_0px_4px_0px_#ffffff33] hover:bg-[#d6d3ce]/90">
            <span className="font-text-regular-medium font-[number:var(--text-regular-medium-font-weight)] text-black text-[length:var(--text-regular-medium-font-size)] tracking-[var(--text-regular-medium-letter-spacing)] leading-[var(--text-regular-medium-line-height)] whitespace-nowrap [font-style:var(--text-regular-medium-font-style)]">
              Join
            </span>
          </Button>

          <Button className="px-6 py-2.5 bg-[#f2f2f2] rounded-[100px] border-2 border-solid border-black shadow-[0px_2px_2px_#00000026,inset_0px_-5px_0px_#00000026,inset_0px_4px_0px_#ffffff33] hover:bg-[#f2f2f2]/90">
            <span className="font-text-regular-medium font-[number:var(--text-regular-medium-font-weight)] text-black text-[length:var(--text-regular-medium-font-size)] tracking-[var(--text-regular-medium-letter-spacing)] leading-[var(--text-regular-medium-line-height)] whitespace-nowrap [font-style:var(--text-regular-medium-font-style)]">
              Learn More
            </span>
          </Button>
        </div>
      </div>

      <img
        className="w-full h-auto max-h-[738px] object-cover rounded-md"
        alt="Placeholder image"
        src="/placeholder-image-2.png"
      />
    </section>
  );
};
