import { ChevronRightIcon } from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";

// Feature data for mapping
const features = [
  {
    icon: "/icon---relume.svg",
    title: "Personalized Access",
    description:
      "Deliver unique content experiences tailored to your audience's interests and preferences.",
  },
  {
    icon: "/icon---relume.svg",
    title: "Boost Earnings",
    description:
      "Maximize your revenue potential with every exclusive message sent to your fans.",
  },
];

export const MainContentSection = (): JSX.Element => {
  return (
    <section className="flex flex-col w-full items-start gap-20 px-16 py-28 relative bg-[#14050c]">
      <div className="flex items-center gap-20 relative self-stretch w-full">
        <div className="flex flex-col items-start gap-8 relative flex-1">
          <div className="flex flex-col items-start gap-8 relative self-stretch w-full">
            <div className="items-start self-stretch w-full flex flex-col gap-4 relative">
              <div className="inline-flex items-center relative">
                <span className="relative w-fit mt-[-1.00px] font-heading-desktop-tagline font-[number:var(--heading-desktop-tagline-font-weight)] text-white text-[length:var(--heading-desktop-tagline-font-size)] tracking-[var(--heading-desktop-tagline-letter-spacing)] leading-[var(--heading-desktop-tagline-line-height)] whitespace-nowrap [font-style:var(--heading-desktop-tagline-font-style)]">
                  Engage
                </span>
              </div>

              <div className="flex flex-col items-start gap-6 relative self-stretch w-full">
                <h2 className="text-[length:var(--heading-desktop-h2-font-size)] tracking-[var(--heading-desktop-h2-letter-spacing)] leading-[var(--heading-desktop-h2-line-height)] relative self-stretch mt-[-1.00px] font-heading-desktop-h2 font-[number:var(--heading-desktop-h2-font-weight)] text-white [font-style:var(--heading-desktop-h2-font-style)]">
                  Unlock Exclusive Content with Pay-Per-View
                </h2>

                <p className="self-stretch font-[number:var(--text-medium-normal-font-weight)] text-[length:var(--text-medium-normal-font-size)] leading-[var(--text-medium-normal-line-height)] relative font-text-medium-normal text-white tracking-[var(--text-medium-normal-letter-spacing)] [font-style:var(--text-medium-normal-font-style)]">
                  Our pay-per-view messages feature allows creators to share
                  exclusive content directly with their fans. This innovative
                  approach ensures that supporters receive personalized
                  interactions while creators earn revenue.
                </p>
              </div>
            </div>

            <div className="flex flex-col items-start gap-4 relative self-stretch w-full">
              <div className="flex items-start gap-6 py-2 relative self-stretch w-full">
                {features.map((feature, index) => (
                  <Card
                    key={index}
                    className="flex-1 bg-transparent border-none"
                  >
                    <CardContent className="flex flex-col items-start gap-4 p-0">
                      <img
                        className="w-12 h-12"
                        alt="Icon relume"
                        src={feature.icon}
                      />
                      <h6 className="self-stretch font-heading-desktop-h6 font-[number:var(--heading-desktop-h6-font-weight)] text-white text-[length:var(--heading-desktop-h6-font-size)] tracking-[var(--heading-desktop-h6-letter-spacing)] leading-[var(--heading-desktop-h6-line-height)] [font-style:var(--heading-desktop-h6-font-style)]">
                        {feature.title}
                      </h6>
                      <p className="self-stretch font-[number:var(--text-regular-normal-font-weight)] text-[length:var(--text-regular-normal-font-size)] leading-[var(--text-regular-normal-line-height)] font-text-regular-normal text-white tracking-[var(--text-regular-normal-letter-spacing)] [font-style:var(--text-regular-normal-font-style)]">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6 relative">
            <Button
              variant="outline"
              className="px-6 py-2.5 bg-[#f2f2f2] rounded-[100px] border-2 border-solid border-black shadow-[0px_2px_2px_#00000026,inset_0px_-5px_0px_#00000026,inset_0px_4px_0px_#ffffff33] text-black"
            >
              <span className="font-text-regular-medium font-[number:var(--text-regular-medium-font-weight)] text-[length:var(--text-regular-medium-font-size)] tracking-[var(--text-regular-medium-letter-spacing)] leading-[var(--text-regular-medium-line-height)] [font-style:var(--text-regular-medium-font-style)]">
                Learn More
              </span>
            </Button>

            <Button
              variant="ghost"
              className="flex items-center justify-center gap-2 p-0 rounded-[100px] text-white"
            >
              <span className="font-text-regular-medium font-[number:var(--text-regular-medium-font-weight)] text-[length:var(--text-regular-medium-font-size)] tracking-[var(--text-regular-medium-letter-spacing)] leading-[var(--text-regular-medium-line-height)] [font-style:var(--text-regular-medium-font-style)]">
                Sign Up
              </span>
              <ChevronRightIcon className="w-6 h-6" />
            </Button>
          </div>
        </div>

        <img
          className="flex-1 h-[640px] object-cover"
          alt="Placeholder image"
          src="/placeholder-image-5.png"
        />
      </div>
    </section>
  );
};
