import React from "react";
import { Button } from "../../../../components/ui/button";

export const CallToActionSection = (): JSX.Element => {
  return (
    <section className="relative w-full py-28 px-16 flex flex-col items-start gap-20 bg-cover bg-center [background:linear-gradient(0deg,rgba(0,0,0,0.5)_0%,rgba(0,0,0,0.5)_100%),url(..//cta---3--.png)_50%_50%_/_cover]">
      <div className="flex flex-col items-start gap-8 max-w-[768px]">
        <div className="flex flex-col items-start gap-6 w-full">
          <h2 className="text-[length:var(--heading-desktop-h2-font-size)] tracking-[var(--heading-desktop-h2-letter-spacing)] leading-[var(--heading-desktop-h2-line-height)] mt-[-1.00px] font-heading-desktop-h2 font-[number:var(--heading-desktop-h2-font-weight)] text-white [font-style:var(--heading-desktop-h2-font-style)]">
            Start Monetizing Your Content Today
          </h2>

          <p className="font-[number:var(--text-medium-normal-font-weight)] text-[length:var(--text-medium-normal-font-size)] leading-[var(--text-medium-normal-line-height)] font-text-medium-normal text-white tracking-[var(--text-medium-normal-letter-spacing)] [font-style:var(--text-medium-normal-font-style)]">
            Join our platform and unlock new revenue streams while connecting
            with your audience like never before.
          </p>
        </div>

        <div className="flex items-start gap-4">
          <Button className="px-6 py-2.5 mt-[-2.00px] mb-[-2.00px] ml-[-2.00px] bg-[#d6d3ce] rounded-[100px] border-2 border-solid border-black shadow-[0px_2px_2px_#00000026,inset_0px_-5px_0px_#00000026,inset_0px_4px_0px_#ffffff33]">
            <span className="font-text-regular-medium font-[number:var(--text-regular-medium-font-weight)] text-black text-[length:var(--text-regular-medium-font-size)] tracking-[var(--text-regular-medium-letter-spacing)] leading-[var(--text-regular-medium-line-height)] whitespace-nowrap [font-style:var(--text-regular-medium-font-style)]">
              Sign Up
            </span>
          </Button>

          <Button
            className="px-6 py-2.5 mt-[-2.00px] mb-[-2.00px] mr-[-2.00px] bg-[#f2f2f2] rounded-[100px] border-2 border-solid border-black shadow-[0px_2px_2px_#00000026,inset_0px_-5px_0px_#00000026,inset_0px_4px_0px_#ffffff33]"
            variant="outline"
          >
            <span className="font-text-regular-medium font-[number:var(--text-regular-medium-font-weight)] text-black text-[length:var(--text-regular-medium-font-size)] tracking-[var(--text-regular-medium-letter-spacing)] leading-[var(--text-regular-medium-line-height)] whitespace-nowrap [font-style:var(--text-regular-medium-font-style)]">
              Learn More
            </span>
          </Button>
        </div>
      </div>
    </section>
  );
};
