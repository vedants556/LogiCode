import { ChevronRightIcon } from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";

// Feature data for mapping
const features = [
  {
    title: "Flexible Earnings",
    description:
      "Set your own subscription rates and enjoy recurring income from loyal fans.",
  },
  {
    title: "Exclusive Content",
    description:
      "Share premium posts and messages that only subscribers can access.",
  },
];

export const MainLayoutSection = (): JSX.Element => {
  return (
    <section className="flex flex-col w-full items-center gap-20 px-16 py-28 bg-[#140f05]">
      <div className="flex flex-col md:flex-row items-center gap-20 w-full">
        <div className="flex-1">
          <img
            className="w-full h-[640px] object-cover rounded-md"
            alt="Placeholder image"
            src="/placeholder-image-5.png"
          />
        </div>

        <div className="flex flex-col items-start gap-8 flex-1">
          <div className="flex flex-col items-start gap-8 w-full">
            <div className="flex flex-col items-start gap-4 w-full">
              <span className="font-heading-desktop-tagline font-[number:var(--heading-desktop-tagline-font-weight)] text-white text-[length:var(--heading-desktop-tagline-font-size)] tracking-[var(--heading-desktop-tagline-letter-spacing)] leading-[var(--heading-desktop-tagline-line-height)] [font-style:var(--heading-desktop-tagline-font-style)]">
                Empower
              </span>

              <div className="flex flex-col items-start gap-6 w-full">
                <h2 className="text-[length:var(--heading-desktop-h2-font-size)] tracking-[var(--heading-desktop-h2-letter-spacing)] leading-[var(--heading-desktop-h2-line-height)] font-heading-desktop-h2 font-[number:var(--heading-desktop-h2-font-weight)] text-white [font-style:var(--heading-desktop-h2-font-style)]">
                  Unlock Your Earning Potential with Subscriptions
                </h2>

                <p className="font-text-medium-normal font-[number:var(--text-medium-normal-font-weight)] text-[length:var(--text-medium-normal-font-size)] leading-[var(--text-medium-normal-line-height)] text-white tracking-[var(--text-medium-normal-letter-spacing)] [font-style:var(--text-medium-normal-font-style)]">
                  Our monthly subscriptions allow creators to earn consistent
                  revenue. Engage your audience with exclusive content tailored
                  just for them.
                </p>
              </div>
            </div>

            <div className="flex flex-col items-start gap-4 w-full">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-2 w-full">
                {features.map((feature, index) => (
                  <Card key={index} className="bg-transparent border-none">
                    <CardContent className="p-0 flex flex-col items-start gap-4">
                      <h6 className="text-[length:var(--heading-desktop-h6-font-size)] tracking-[var(--heading-desktop-h6-letter-spacing)] leading-[var(--heading-desktop-h6-line-height)] font-heading-desktop-h6 font-[number:var(--heading-desktop-h6-font-weight)] text-white [font-style:var(--heading-desktop-h6-font-style)]">
                        {feature.title}
                      </h6>
                      <p className="font-text-regular-normal font-[number:var(--text-regular-normal-font-weight)] text-[length:var(--text-regular-normal-font-size)] leading-[var(--text-regular-normal-line-height)] text-white tracking-[var(--text-regular-normal-letter-spacing)] [font-style:var(--text-regular-normal-font-style)]">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <Button
              variant="outline"
              className="bg-[#f2f2f2] text-black rounded-[100px] px-6 py-2.5 border-2 border-black shadow-[0px_2px_2px_#00000026,inset_0px_-5px_0px_#00000026,inset_0px_4px_0px_#ffffff33]"
            >
              <span className="font-text-regular-medium font-[number:var(--text-regular-medium-font-weight)] text-[length:var(--text-regular-medium-font-size)] tracking-[var(--text-regular-medium-letter-spacing)] leading-[var(--text-regular-medium-line-height)] [font-style:var(--text-regular-medium-font-style)]">
                Learn More
              </span>
            </Button>

            <Button
              variant="ghost"
              className="text-white rounded-[100px] p-0 flex items-center gap-2"
            >
              <span className="font-text-regular-medium font-[number:var(--text-regular-medium-font-weight)] text-[length:var(--text-regular-medium-font-size)] tracking-[var(--text-regular-medium-letter-spacing)] leading-[var(--text-regular-medium-line-height)] [font-style:var(--text-regular-medium-font-style)]">
                Sign Up
              </span>
              <ChevronRightIcon className="w-6 h-6" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
