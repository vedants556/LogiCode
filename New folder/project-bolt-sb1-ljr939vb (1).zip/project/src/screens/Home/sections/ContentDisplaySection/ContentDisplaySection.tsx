import { ChevronRightIcon } from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";

// Feature card data for mapping
const featureCards = [
  {
    title: "Designed for Ease of Use and Accessibility",
    description: "Our platform is intuitive, making navigation effortless.",
    iconSrc: "/icon---relume.svg",
    iconAlt: "Icon relume",
  },
  {
    title: "Robust Security Measures for Your Peace of Mind",
    description:
      "We implement advanced security protocols to safeguard your content.",
    iconSrc: "/icon---relume.svg",
    iconAlt: "Icon relume",
  },
  {
    title: "Empowering Creators with User-Friendly Tools",
    description: "Our tools are designed to help creators thrive.",
    iconSrc: "/icon---relume.svg",
    iconAlt: "Icon relume",
  },
];

export const ContentDisplaySection = (): JSX.Element => {
  return (
    <section className="flex flex-col items-center gap-20 px-16 py-28 bg-[#140f05] w-full">
      <div className="max-w-[768px] items-center flex flex-col gap-4">
        <div className="inline-flex items-center">
          <span className="font-heading-desktop-tagline font-[number:var(--heading-desktop-tagline-font-weight)] text-white text-[length:var(--heading-desktop-tagline-font-size)] text-center tracking-[var(--heading-desktop-tagline-letter-spacing)] leading-[var(--heading-desktop-tagline-line-height)] whitespace-nowrap [font-style:var(--heading-desktop-tagline-font-style)]">
            Secure
          </span>
        </div>

        <div className="flex flex-col items-center gap-6 w-full">
          <h2 className="text-[length:var(--heading-desktop-h2-font-size)] text-center tracking-[var(--heading-desktop-h2-letter-spacing)] leading-[var(--heading-desktop-h2-line-height)] font-heading-desktop-h2 font-[number:var(--heading-desktop-h2-font-weight)] text-white [font-style:var(--heading-desktop-h2-font-style)]">
            Your Privacy and Security Are Our Priority
          </h2>

          <p className="font-[number:var(--text-medium-normal-font-weight)] text-[length:var(--text-medium-normal-font-size)] text-center leading-[var(--text-medium-normal-line-height)] font-text-medium-normal text-white tracking-[var(--text-medium-normal-letter-spacing)] [font-style:var(--text-medium-normal-font-style)]">
            We prioritize your privacy and security, ensuring that your data is
            protected at all times. Our user-friendly design makes it easy for
            creators and fans to connect seamlessly.
          </p>
        </div>
      </div>

      <div className="flex flex-col items-start gap-16 w-full">
        <div className="flex items-start gap-12 w-full">
          {featureCards.map((card, index) => (
            <Card key={index} className="flex-1 bg-transparent border-none">
              <CardContent className="flex flex-col items-center gap-6 p-0">
                <img
                  className="w-12 h-12"
                  alt={card.iconAlt}
                  src={card.iconSrc}
                />

                <div className="flex flex-col items-center gap-6 w-full">
                  <h4 className="text-[length:var(--heading-desktop-h4-font-size)] text-center tracking-[var(--heading-desktop-h4-letter-spacing)] leading-[var(--heading-desktop-h4-line-height)] font-heading-desktop-h4 font-[number:var(--heading-desktop-h4-font-weight)] text-white [font-style:var(--heading-desktop-h4-font-style)]">
                    {card.title}
                  </h4>

                  <p className="font-[number:var(--text-regular-normal-font-weight)] text-[length:var(--text-regular-normal-font-size)] text-center leading-[var(--text-regular-normal-line-height)] font-text-regular-normal text-white tracking-[var(--text-regular-normal-letter-spacing)] [font-style:var(--text-regular-normal-font-style)]">
                    {card.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-6">
        <Button
          className="px-6 py-2.5 bg-[#f2f2f2] rounded-[100px] border-2 border-solid border-black shadow-[0px_2px_2px_#00000026,inset_0px_-5px_0px_#00000026,inset_0px_4px_0px_#ffffff33]"
          variant="outline"
        >
          <span className="font-text-regular-medium font-[number:var(--text-regular-medium-font-weight)] text-black text-[length:var(--text-regular-medium-font-size)] tracking-[var(--text-regular-medium-letter-spacing)] leading-[var(--text-regular-medium-line-height)] whitespace-nowrap [font-style:var(--text-regular-medium-font-style)]">
            Learn More
          </span>
        </Button>

        <Button
          className="flex items-center justify-center gap-2 rounded-[100px] bg-transparent p-0"
          variant="ghost"
        >
          <span className="font-text-regular-medium font-[number:var(--text-regular-medium-font-weight)] text-white text-[length:var(--text-regular-medium-font-size)] tracking-[var(--text-regular-medium-letter-spacing)] leading-[var(--text-regular-medium-line-height)] whitespace-nowrap [font-style:var(--text-regular-medium-font-style)]">
            Sign Up
          </span>
          <ChevronRightIcon className="w-6 h-6" />
        </Button>
      </div>
    </section>
  );
};
